# Güvenli Adımlar - GitHub Otomatik APK Üretim Projesi

Bu proje, bilgisayarınıza Android Studio veya Java kurmanıza gerek kalmadan **GitHub Actions** üzerinde otomatik olarak `.apk` dosyası üretir.

## Nasıl APK Üretilir? (3 Adım)

1. **GitHub'da Yeni Depo (Repository) Açın:**
   - [github.com/new](https://github.com/new) adresine gidin ve `guvenli-adimlar` adında yeni bir depo oluşturun.
2. **Dosyaları Yükleyin:**
   - Bu ZIP içindeki tüm dosya ve klasörleri (`.github` klasörü dahil) deponuza yükleyin ve **Commit changes** butonuna basın.
3. **APK'yı İndirin:**
   - GitHub deponuzun üst menüsünden **Actions** sekmesine tıklayın.
   - **Android APK Derleyici (Guvenli Adimlar)** işleminin tamamlanmasını bekleyin (yaklaşık 2-3 dakika sürer).
   - İşlem yeşil onay aldıktan sonra içine girip en alttaki **Artifacts** bölümünden **`Guvenli-Adimlar-APK`** dosyasını telefonunuza veya bilgisayarınıza indirin.
