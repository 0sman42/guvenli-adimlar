package com.guvenliadimlar.app

import android.app.usage.UsageStatsManager
import android.content.Context
import java.util.Calendar

data class AppUsageItem(val packageName: String, val minutes: Long)

object UsageStatsHelper {
    fun getDailyUsage(context: Context): List<AppUsageItem> {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
        }
        val stats = usm.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            cal.timeInMillis,
            System.currentTimeMillis()
        )
        return stats
            .filter { it.totalTimeInForeground >= 60_000L }
            .map { AppUsageItem(it.packageName, it.totalTimeInForeground / 60_000L) }
            .sortedByDescending { it.minutes }
    }
}
