package com.guvenliadimlar.app

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor

class DnsMonitorVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (vpnInterface == null) {
            val builder = Builder()
                .setSession("Güvenli Adımlar Alan Adı Koruması")
                .addAddress("10.0.0.2", 32)
                .addDnsServer("8.8.8.8")
                .addRoute("8.8.8.8", 32)
            vpnInterface = builder.establish()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        vpnInterface?.close()
        vpnInterface = null
        super.onDestroy()
    }
}
